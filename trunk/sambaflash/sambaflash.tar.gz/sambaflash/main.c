/************************************************************************
 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.                                  *
 *                                                                      *
 * Author: Yury Ovcharenko <amwsoft@gmail.com>                          *
 ************************************************************************/

#include "at91sam7.h"
#include "pio.h"
#include "serial.h"
#include "funcs.h"
#include "flash.h"

extern unsigned long _pageaddr;
extern unsigned long _pagelen;
extern int _retval;
extern unsigned long _buffer;

int main(void)
{
	unsigned long pageaddr = _pageaddr;
	unsigned long pagesize = _pagelen;
	unsigned long *pagebuf = &_buffer;

	int retval;
	int i;
	char buf[257];
	char *C;
	struct EFC_t *EFC = EFC_BASE;

	pio_init();
	serial_init();
	flash_init();
	
	retval = flash_writepage((unsigned long *)pageaddr, pagebuf, pagesize);
	_retval = retval;
	
	pio_write(0x7);
	
	return retval;
}
